Dilwar Govey - مشروع أندرويد أولي يعمل دون اتصال

المحتويات:
- app/src/main/assets/index.html: واجهة التطبيق المحلية.
- MainActivity.java: غلاف Android WebView.
- لا توجد صلاحية إنترنت في AndroidManifest.xml.
- التخزين التجريبي يتم محلياً عبر localStorage داخل WebView.

طريقة فتح المشروع:
1) ثبّت Android Studio على جهاز كمبيوتر.
2) فك ضغط DilwarGoveyAndroid.zip.
3) من Android Studio اختر Open ثم مجلد DilwarGoveyAndroid.
4) انتظر Gradle Sync وثبّت Android SDK Platform 35 إذا طُلب.
5) للتجربة: Run على هاتف أندرويد مع تفعيل USB debugging.
6) لإنشاء APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
7) للنشر على Google Play: أنشئ Android App Bundle (AAB) موقّعاً من Build > Generate Signed Bundle / APK.

مهم:
- هذا مشروع مصدر أولي، وليس APK/AAB جاهزاً.
- يحتاج إلى Android Studio وAndroid SDK لبناء ملفات التثبيت.
- قبل النشر العام يجب اختبار التخزين والنسخ الاحتياطي والخصوصية وإكمال متطلبات Google Play.
- لا ترفع مفاتيح التوقيع أو كلمات المرور إلى أي مكان عام.
